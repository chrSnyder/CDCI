x = seq(0, 2*pi, by=pi/100)

plot(x, sin(x), type="l")